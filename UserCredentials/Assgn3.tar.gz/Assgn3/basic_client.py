# #print("Reciver")
# # Import socket module
# import socket
# import sys
# import subprocess
# import os
#
# s = socket.socket()
#
# # connect to the server on local computer
# s.connect(("127.0.0.1", 12345))
#
# # receive data from the server
# x=s.recv(1024)
# print(x.decode())
# ss1="Hey, its basic_client!"
# s.send(ss1.encode())
# # close the connection
# s.close()


# import socket
# hostname = socket.gethostname()
# local_ip = socket.gethostbyname(hostname)
# print(hostname)
# print(local_ip)
